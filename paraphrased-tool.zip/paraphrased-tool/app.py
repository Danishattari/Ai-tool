from flask import Flask, request, jsonify
from flask_cors import CORS
from pydantic import BaseModel
from typing import List
from helpers import structured_generator
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for all domains

class ParaphrasedText(BaseModel):
    paraphrased: str
    variations: List[str]

@app.route('/paraphrase', methods=['POST'])
def paraphrase():
    try:
        data = request.json
        text = data.get('text', '')
        style = data.get('style', 'Professional')
        
        prompt = f"""Paraphrase the following text in a {style.lower()} style. 
        Provide the main paraphrased version and 2 alternative variations.
        Original text: {text}"""
        
        openai_model = "gpt-3.5-turbo"
        result = structured_generator(openai_model, prompt, ParaphrasedText)
        
        # Assuming 'result' is a dictionary-like object
        return jsonify({
            'paraphrased': result.get('paraphrased'),
            'variations': result.get('variations')
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
